def lockup(h=46, color=None, stack=True):
    # dragonfly + live wordmark; h = dragonfly height px
    fs=h*0.43
    wm='Soaring<br>Dragonfly<br>Institute<sup>TM</sup>' if stack else 'Soaring Dragonfly Institute<sup>TM</sup>'
    st=f'font-size:{fs:.1f}px;'+(f'color:{color};' if color else '')
    return f'<div class="lockup"><img src="assets/dragonfly.png" style="height:{h}px;width:{h}px"><div class="wm" style="{st}">{wm}</div></div>'
