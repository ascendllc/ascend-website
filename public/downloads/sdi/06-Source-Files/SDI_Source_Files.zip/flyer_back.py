from lockup import lockup
html=f'''<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="brand.css"><style>
body{{width:816px;height:1056px}} .page{{width:816px;height:1056px;padding:48px 56px 0}}
.top{{position:relative;z-index:2;display:flex;justify-content:space-between;align-items:flex-start}}
.eyebrow{{font-size:11px;letter-spacing:2.4px;font-weight:700;color:var(--blue);text-align:right;margin-top:6px}}
h1{{font-family:Cormorant;font-weight:600;font-size:54px;line-height:1;color:var(--plum);margin-top:10px;letter-spacing:.5px}}
.sub{{font-family:Cormorant;font-style:italic;font-weight:500;font-size:26px;color:var(--green);margin-top:2px}}
.intro{{font-size:15.5px;line-height:1.6;margin-top:8px;max-width:640px;color:var(--body)}}
.wp{{font-family:Cormorant;font-style:italic;font-weight:600;font-size:23px;color:var(--plum);margin-top:10px}}
.cols{{display:grid;grid-template-columns:1fr 1fr;grid-template-rows:repeat(3,auto);grid-auto-flow:column;gap:4px 36px;margin-top:8px}}
.cols div{{font-size:14px;padding-left:20px;position:relative;line-height:1.4;color:var(--ink)}}
.cols div:before{{content:"";position:absolute;left:0;top:6px;width:8px;height:8px;border-radius:50%;background:var(--lav)}}
.details{{display:grid;grid-template-columns:1fr 1fr;gap:0;margin-top:12px;background:#fff;border-radius:16px;border:1px solid #d3e2eb}}
.details>div{{padding:12px 22px;border-right:1px solid #e3ecf3}} .details>div:nth-child(2){{border-right:none}} .details>.cost{{grid-column:1/-1;border-right:none;border-top:1px solid #e3ecf3;display:grid;grid-template-columns:325px 1fr;gap:14px;align-items:center}} .pr{{font-family:Cormorant;font-weight:700;font-size:25px;line-height:1.08;color:var(--ink);white-space:nowrap}} .vv{{font-size:13px;margin-top:6px;color:var(--plum);font-weight:700;letter-spacing:.4px}} .il{{margin:3px 0 0 14px;padding:0}} .il li{{margin-top:1px}} .inc{{font-size:10px;line-height:1.32;color:var(--body);border-left:1px solid #e3ecf3;padding-left:14px}}
.k{{font-size:10.5px;letter-spacing:2.2px;font-weight:700;color:var(--green);margin-bottom:6px}}
.v{{font-family:Cormorant;font-weight:600;font-size:25px;line-height:1.1;color:var(--ink)}}
.s{{font-size:13px;margin-top:5px;line-height:1.4}}
.don{{margin-top:14px;font-size:13.5px;text-align:center;color:var(--ink)}} .don b{{color:var(--plum)}}
.guides{{margin-top:12px;display:grid;grid-template-columns:auto 1fr;gap:26px;align-items:center}}
.heads{{display:flex;gap:16px}} .hd{{text-align:center;width:92px}}
.hd img{{width:62px;height:62px;border-radius:50%;object-fit:cover;border:3px solid var(--lav);display:block;margin:0 auto 6px}}
.hd .n{{font-family:Cormorant;font-style:italic;font-weight:600;font-size:17px;color:var(--ink);line-height:1.05}}
.gl{{font-size:10.5px;letter-spacing:2.2px;font-weight:700;color:var(--green);margin-bottom:6px}}
.q{{font-family:Cormorant;font-style:italic;font-weight:500;font-size:17.5px;line-height:1.3;color:var(--ink)}}
.gs{{font-size:12.5px;margin-top:6px;color:var(--body)}}
.tm{{margin-top:6px;text-align:center;font-family:Cormorant;font-style:italic;font-weight:500;font-size:20px;color:var(--plum)}} .tm small{{display:inline;margin-left:12px;font-family:Lato;font-style:normal;font-size:10.5px;letter-spacing:1.6px;color:var(--blue);margin-top:3px}}
.band{{position:absolute;left:0;right:0;bottom:0;height:112px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;padding:16px 56px 0;display:flex;justify-content:space-between}}
.band .r{{font-family:Cormorant;font-weight:600;font-size:36px;line-height:1}}
.band .u{{font-size:18px;letter-spacing:.7px;font-weight:700;margin-top:6px}}
.band .t{{font-size:12px;color:#dcecf7;margin-top:4px}}
.qr{{background:#fff;border-radius:12px;padding:7px;width:80px;height:80px}} .qr img{{width:68px;display:block}}
.fn{{display:block;margin-bottom:5px;color:#4d6680}}
.disc{{position:absolute;left:56px;right:56px;bottom:122px;font-size:8.4px;line-height:1.4;color:#5b6f85;text-align:center}}
</style></head><body><div class="page">
<img class="sp" src="assets/spiral_lav.svg" style="width:340px;right:-190px;top:-190px;opacity:.35">

<div class="top">{lockup(46)}<div class="eyebrow">A SOUL SESSION<br>EXPERIENTIAL WELLNESS PRACTICE</div></div>
<h1>Love Yourself Now</h1><div class="sub">Acknowledging Reality with Hope</div>
<div class="intro">A grown-up circle time, book-club style, for honest sharing and connection. No experience needed, and no pressure to share more than you want to.</div>
<div class="wp">What you'll practice</div>
<div class="cols"><div>A daily writing practice adapted from<br><i>The Artist's Way</i> by Julia Cameron</div><div>A simple tool for sorting what's<br>yours to carry from what isn't</div><div>Ways to name what you feel,<br>even when words won't come</div><div>Gentle movement to reconnect with the body</div><div>A clear structure for practice</div></div>
<div class="details"><div><div class="k">WHEN</div><div class="v">Nov 5 or Nov 12</div><div class="s">Thursdays, 6:30 to 8:30 PM<br>Pick the Thursday that suits your schedule.</div></div>
<div><div class="k">WHERE</div><div class="v">The Mountaineers</div><div class="s">Boardroom<br>2302 N 30th St, Tacoma, WA 98403</div></div>
<div class="cost"><div><div class="k">COST</div><div class="pr">$35 early bird through Oct 29,<br>$50 advance, $60 at the door.</div><div class="vv">A $497 value*</div></div><div class="inc"><b>*What the $497 value includes:</b><ul class="il"><li>Two hours led by a credentialed guide who walks this road alongside you</li><li>A daily writing practice adapted from <i>The Artist's Way</i> by Julia Cameron</li><li>Growing awareness of the experience of heart, mind, and body alignment</li><li>Ways to name what you feel, even when words won't come</li><li>Gentle movement</li><li>A clear structure for practice</li></ul></div></div></div>
<div class="guides"><div class="heads"><div class="hd"><img src="assets/vonna.png"><div class="n">Von-Na<br>Chism</div></div><div class="hd"><img src="assets/imeko.png"><div class="n">Imeko<br>Woods</div></div><div class="hd"><img src="assets/camella.png"><div class="n">Camella<br>McBrayer</div></div></div>
<div><div class="gl">YOUR GUIDE</div><div class="q">"Montessori shows us that children learn by doing. Adults learn the same way. We built this circle so you can practice self-kindness, on paper and in your body. Come as you are. We saved you a seat."</div><div class="gs">Credentialed Guides that Share the Journey<br>One of these credentialed guides will lead your evening.</div></div></div>
<div class="disc"><b>Notice and Disclaimer:</b> This group utilizes peer-led Experiential Wellness Practices for general personal growth and recovery support. It is facilitated by a Peer Support Specialist and is completely non-clinical. These exercises are not a substitute for experiential therapy, psychotherapy, or medical treatment. Participation does not establish a clinician-client relationship. <i>The Artist's Way</i> is a book by Julia Cameron; this event is not affiliated with the author or publisher.</div>
<div class="band"><div><div class="r">Save your seat</div><div class="u">soaringdragonflyinstitute.com</div><div class="t">Scan the code or visit the site to register. Groups welcome.</div></div><div class="qr"><img src="assets/qr_flyer.png"></div></div>
</div></body></html>'''
open('flyer_back.html','w').write(html)
