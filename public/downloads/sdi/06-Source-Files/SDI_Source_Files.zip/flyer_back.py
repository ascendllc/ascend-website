from lockup import lockup
html=f'''<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="brand.css"><style>
body{{width:816px;height:1056px}} .page{{width:816px;height:1056px;padding:48px 56px 0}}
.top{{position:relative;z-index:2;display:flex;justify-content:space-between;align-items:flex-start}}
.eyebrow{{font-size:11px;letter-spacing:2.4px;font-weight:700;color:var(--blue);text-align:right;margin-top:6px}}
h1{{font-family:Cormorant;font-weight:600;font-size:60px;line-height:1;color:var(--plum);margin-top:20px;letter-spacing:.5px}}
.sub{{font-family:Cormorant;font-style:italic;font-weight:500;font-size:29px;color:var(--green);margin-top:2px}}
.intro{{font-size:15.5px;line-height:1.6;margin-top:12px;max-width:620px;color:var(--body)}}
.cols{{display:grid;grid-template-columns:1fr 1fr;gap:4px 36px;margin-top:14px}}
.cols div{{font-size:14.5px;padding-left:20px;position:relative;line-height:1.4;color:var(--ink)}}
.cols div:before{{content:"";position:absolute;left:0;top:6px;width:8px;height:8px;border-radius:50%;background:var(--lav)}}
.details{{display:grid;grid-template-columns:1fr 1.15fr 1.1fr;gap:0;margin-top:16px;background:#fff;border-radius:16px;border:1px solid #d3e2eb}}
.details>div{{padding:18px 22px;border-right:1px solid #e3ecf3}} .details>div:last-child{{border:none}}
.k{{font-size:10.5px;letter-spacing:2.2px;font-weight:700;color:var(--green);margin-bottom:6px}}
.v{{font-family:Cormorant;font-weight:600;font-size:27px;line-height:1.1;color:var(--ink)}}
.s{{font-size:13px;margin-top:5px;line-height:1.4}}
.don{{margin-top:14px;font-size:13.5px;text-align:center;color:var(--ink)}} .don b{{color:var(--plum)}}
.guides{{margin-top:22px;display:grid;grid-template-columns:auto 1fr;gap:26px;align-items:center}}
.heads{{display:flex;gap:16px}} .hd{{text-align:center;width:98px}}
.hd img{{width:88px;height:88px;border-radius:50%;object-fit:cover;border:3px solid var(--lav);display:block;margin:0 auto 6px}}
.hd .n{{font-family:Cormorant;font-style:italic;font-weight:600;font-size:19px;color:var(--ink);line-height:1.05}}
.gl{{font-size:10.5px;letter-spacing:2.2px;font-weight:700;color:var(--green);margin-bottom:6px}}
.q{{font-family:Cormorant;font-style:italic;font-weight:500;font-size:19px;line-height:1.32;color:var(--ink)}}
.gs{{font-size:12.5px;margin-top:6px;color:var(--body)}}
.tm{{margin-top:8px;text-align:center;font-family:Cormorant;font-style:italic;font-weight:500;font-size:20px;color:var(--plum)}} .tm small{{display:inline;margin-left:12px;font-family:Lato;font-style:normal;font-size:10.5px;letter-spacing:1.6px;color:var(--blue);margin-top:3px}}
.band{{position:absolute;left:0;right:0;bottom:0;height:160px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;padding:26px 56px 0;display:flex;justify-content:space-between}}
.band .r{{font-family:Cormorant;font-weight:600;font-size:40px;line-height:1}}
.band .u{{font-size:19px;letter-spacing:.7px;font-weight:700;margin-top:10px}}
.band .t{{font-size:12.5px;color:#dcecf7;margin-top:6px}}
.qr{{background:#fff;border-radius:12px;padding:8px;width:110px;height:110px}} .qr img{{width:94px;display:block}}
.fn{{display:block;margin-bottom:5px;color:#4d6680}}
.disc{{position:absolute;left:56px;right:56px;bottom:176px;font-size:8.4px;line-height:1.4;color:#5b6f85;text-align:center}}
</style></head><body><div class="page">
<img class="sp" src="assets/spiral_lav.svg" style="width:340px;right:-190px;top:-190px;opacity:.35">

<div class="top">{lockup(46)}<div class="eyebrow">A SOUL SESSION<br>EXPERIENTIAL WELLNESS PRACTICE</div></div>
<h1>Love Yourself Now</h1><div class="sub">Acknowledging Reality with Hope</div>
<div class="intro">A grown-up circle time, book-club style, for honest sharing and connection. No experience needed, and no pressure to share more than you want to.</div>
<div class="cols"><div>Morning pages from <i>The Artist's Way</i> by Julia Cameron, with two added practices</div><div>A To Do list and a To Be list, with a release ceremony</div><div>A 10-minute yoga practice for your inner child</div><div>A floor feeling wheel, to check in without speaking</div><div>Take home: an inner child stuffed animal, an Artist Date bag, a resource packet</div><div>Honest sharing, a refreshment break, and a closing practice</div></div>
<div class="details"><div><div class="k">WHEN</div><div class="v">Thu, Nov 5</div><div class="s">6:30 to 8:30 PM<br>A 2-hour Soul Session</div></div>
<div><div class="k">WHERE</div><div class="v">Central Co-op</div><div class="s">4502 N Pearl St<br>Tacoma, WA 98407</div></div>
<div><div class="k">COST</div><div class="v">Free to attend</div><div class="s">A $497 value*. Donations gratefully accepted, never required</div></div></div>
<div class="don"><span class="sg">Suggested: <b>$35</b> early bird through Oct 29, <b>$50</b> advance, <b>$60</b> at the door.</span></div>
<div class="guides"><div class="heads"><div class="hd"><img src="assets/vonna.png"><div class="n">Von-Na<br>Chism</div></div><div class="hd"><img src="assets/imeko.png"><div class="n">Imeko<br>Woods</div></div><div class="hd"><img src="assets/camella.png"><div class="n">Camella<br>McBrayer</div></div></div>
<div><div class="gl">YOUR GUIDES</div><div class="q">"Montessori shows us that children learn by doing. Adults learn the same way. We built this circle so you can practice self-kindness, on paper and in your body. Come as you are. We saved you a seat."</div><div class="gs">Credentialed Guides with Lived Experience</div></div></div>
<div class="disc"><span class="fn">*The $497 value reflects a Credentialed Guide leading the full two hours, a guided practice from <i>The Artist's Way</i> by Julia Cameron, a body-based practice, nonverbal check-in options, take-home items and a complete experience in one evening.</span><br><b>Notice and Disclaimer:</b> This group utilizes peer-led Experiential Wellness Practices for general personal growth and recovery support. It is facilitated by a Peer Support Specialist and is completely non-clinical. These exercises are not a substitute for experiential therapy, psychotherapy, or medical treatment. Participation does not establish a clinician-client relationship. <i>The Artist's Way</i> is a book by Julia Cameron; this event is not affiliated with the author or publisher. This event is not sponsored by Central Co-op.</div>
<div class="band"><div><div class="r">Save your seat</div><div class="u">soaringdragonflyinstitute.com</div><div class="t">Scan the code or visit the site to register. Groups welcome.</div></div><div class="qr"><img src="assets/qr_flyer.png"></div></div>
</div></body></html>'''
open('flyer_back.html','w').write(html)
