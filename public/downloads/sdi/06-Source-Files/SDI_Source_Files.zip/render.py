import asyncio, sys
from playwright.async_api import async_playwright
async def shot(jobs):
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/opt/pw-browsers/chromium-1194/chrome-linux/chrome' if False else None)
        for j in jobs:
            pg=await b.new_page(viewport={'width':j['w'],'height':j['h']},device_scale_factor=j.get('scale',2))
            await pg.goto('file:///home/claude/sdi/'+j['html']); await pg.wait_for_timeout(400)
            await pg.evaluate('document.fonts.ready')
            if j.get('png'): await pg.screenshot(path=j['png'],clip={'x':0,'y':0,'width':j['w'],'height':j['h']})
            if j.get('pdf'): await pg.pdf(path=j['pdf'],width=f"{j['w']}px",height=f"{j['h']}px",print_background=True,page_ranges='1')
            await pg.close()
        await b.close()
def run(jobs): asyncio.run(shot(jobs))
