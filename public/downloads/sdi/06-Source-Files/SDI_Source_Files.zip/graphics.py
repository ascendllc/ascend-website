from lockup import lockup
import render
HEAD='<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="brand.css"><style>{css}</style></head><body><div class="page">{body}</div></body></html>'
def sp(kind,w,x,y,o=.5): return f'<img class="sp" src="assets/spiral_{kind}.svg" style="width:{w}px;{x};{y};opacity:{o}">'
def write(name,w,h,css,body):
    open(name+'.html','w').write(HEAD.format(css=f'body{{width:{w}px;height:{h}px}}.page{{width:{w}px;height:{h}px}}'+css,body=body))
jobs=[]
def job(name,w,h,png,scale=1): jobs.append(dict(html=name+'.html',w=w,h=h,png=png,scale=scale))

# ---------- Website hero (desktop + mobile)
c='''.in{position:absolute;left:120px;top:0;bottom:0;display:flex;flex-direction:column;justify-content:center}
.k{font-size:18px;letter-spacing:3.4px;font-weight:700;color:var(--blue);margin-bottom:14px}
.h{font-family:Cormorant;font-weight:600;font-size:150px;line-height:.92;color:var(--ink);letter-spacing:-2px}.h em{font-style:italic;color:var(--plum);font-weight:500}
.p{font-family:Cormorant;font-style:italic;font-weight:500;font-size:44px;color:var(--blue);margin-top:18px}
.d{font-size:24px;margin-top:22px;color:var(--ink);letter-spacing:.3px;line-height:1.5}.d b{font-weight:700}
.btn{display:inline-flex;align-items:center;gap:12px;margin-top:26px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;border-radius:40px;padding:18px 40px;font-size:22px;font-weight:700;letter-spacing:.6px;width:max-content;box-shadow:0 8px 22px rgba(44,91,138,.3)}
.df{position:absolute;right:230px;top:90px;width:360px;transform:rotate(8deg)}
.lk{position:absolute;right:70px;top:46px}'''
b=sp('lav',640,'right:-180px','top:-260px',.5)+sp('aqua',520,'right:420px','bottom:-300px',.6)+'<div class="in"><div class="k">LOVE YOURSELF NOW  ·  THURSDAY, NOVEMBER 5</div><div class="h">Find your <em>voice.</em></div><div class="p">It never left. Come practice using it.</div><div class="d"><b>6:30 to 8:30 PM</b> &nbsp;·&nbsp; Central Co-op, 4502 N Pearl St, Tacoma<br>Free to attend. Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span></div><div class="btn">Register below &nbsp;&#8595;</div></div><img class="df" src="assets/dragonfly.png">'
write('hero_desktop',1920,640,c,b); job('hero_desktop',1920,640,'out/web/SDI_Website_Hero_Desktop_1920x640.png')
cm='''.in{position:absolute;left:56px;right:56px;top:70px}
.k{font-size:15px;letter-spacing:2.6px;font-weight:700;color:var(--blue);margin-bottom:16px}
.h{font-family:Cormorant;font-weight:600;font-size:118px;line-height:.9;color:var(--ink);letter-spacing:-1px}.h em{font-style:italic;color:var(--plum);font-weight:500}
.p{font-family:Cormorant;font-style:italic;font-weight:500;font-size:38px;color:var(--blue);margin-top:20px}
.d{font-size:21px;margin-top:22px;color:var(--ink);line-height:1.55}.d b{font-weight:700}
.btn{display:inline-flex;margin-top:30px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;border-radius:40px;padding:18px 40px;font-size:22px;font-weight:700;letter-spacing:.6px;box-shadow:0 8px 22px rgba(44,91,138,.3)}
.df{position:absolute;right:40px;bottom:70px;width:280px;transform:rotate(8deg)}'''
bm=sp('lav',520,'right:-220px','top:-220px',.5)+sp('aqua',520,'left:-260px','bottom:-200px',.6)+'<div class="in"><div class="k">LOVE YOURSELF NOW<br>THURSDAY, NOV 5  ·  TACOMA</div><div class="h">Find<br>your<br><em>voice.</em></div><div class="p">It never left.<br>Come practice using it.</div><div class="d"><b>6:30 to 8:30 PM</b><br>Central Co-op, Tacoma<br>Free to attend. Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29,<br>$50 advance, $60 at the door.</span></div><div class="btn">Register below &nbsp;&#8595;</div></div><img class="df" src="assets/dragonfly.png">'
write('hero_mobile',800,1100,cm,bm); job('hero_mobile',800,1100,'out/web/SDI_Website_Hero_Mobile_800x1100.png')

# ---------- Facebook event cover 1920x1005
c='''.in{position:absolute;left:150px;top:0;bottom:0;display:flex;flex-direction:column;justify-content:center}
.k{font-size:22px;letter-spacing:4px;font-weight:700;color:var(--blue);margin-bottom:18px}
.h{font-family:Cormorant;font-weight:600;font-size:190px;line-height:.9;color:var(--ink);letter-spacing:-2px}.h em{font-style:italic;color:var(--plum);font-weight:500}
.p{font-family:Cormorant;font-style:italic;font-weight:500;font-size:52px;color:var(--blue);margin-top:26px}
.band{position:absolute;left:0;right:0;bottom:0;height:150px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;display:flex;align-items:center;padding:0 150px;gap:46px}
.band .d{font-family:Cormorant;font-weight:600;font-size:54px}.band .l{font-size:24px;line-height:1.4}
.df{position:absolute;right:210px;top:150px;width:420px;transform:rotate(8deg)}.lk{position:absolute;right:120px;top:60px}'''
b=sp('aqua',560,'left:-330px','bottom:-330px',.6)+'<div class="lk">'+lockup(80)+'</div><div class="in"><div class="k">LOVE YOURSELF NOW</div><div class="h">Find your<br><em>voice.</em></div><div class="p">It never left. Come practice using it.</div></div><img class="df" src="assets/dragonfly.png"><div class="band"><div class="d">Thursday, November 5</div><div class="l">6:30 to 8:30 PM  ·  Central Co-op, 4502 N Pearl St, Tacoma<br>Free to attend. Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span></div></div>'
write('fb_cover',1920,1005,c,b); job('fb_cover',1920,1005,'out/social/SDI_Facebook_Event_Cover_1920x1005.png')

# ---------- Social squares 1080
cs='''.in{position:absolute;left:90px;right:90px;top:0;bottom:0;display:flex;flex-direction:column;justify-content:center}
.big{font-family:Cormorant;font-style:italic;font-weight:500;font-size:96px;line-height:1.08;color:var(--ink)}.big .b{color:var(--plum)}
.sm{font-family:Cormorant;font-weight:600;font-size:58px;color:var(--ink);margin-top:40px;line-height:1}.sm em{font-style:italic;color:var(--plum);font-weight:500}
.ft{position:absolute;left:90px;right:90px;bottom:70px;display:flex;justify-content:space-between;align-items:flex-end}
.ft .u{font-size:24px;letter-spacing:1px;font-weight:700;color:var(--blue)}.ft .w{font-size:20px;color:var(--body);margin-top:6px}
.k{font-size:20px;letter-spacing:3.4px;font-weight:700;color:var(--blue);margin-bottom:22px}'''
foot='<div class="ft"><div><div class="u">soaringdragonflyinstitute.com</div><div class="w">Thu, Nov 5  ·  6:30 to 8:30 PM  ·  Central Co-op, Tacoma</div></div></div>'
note='<div style="position:absolute;left:90px;right:90px;bottom:26px;font-size:13px;line-height:1.35;color:#5b6f85"><b>Notice and Disclaimer:</b> This group utilizes peer-led Experiential Wellness Practices for general personal growth and recovery support. It is facilitated by a Peer Support Specialist and is completely non-clinical. These exercises are not a substitute for experiential therapy, psychotherapy, or medical treatment. Participation does not establish a clinician-client relationship.</div>'
foot_hi=foot.replace('class="ft"','class="ft" style="bottom:110px"')
lk=lambda: '<div style="position:absolute;left:90px;top:70px">'+lockup(64)+'</div>'
b1=sp('lav',560,'right:-210px','top:-230px',.5)+lk()+'<img class="sp" src="assets/dragonfly.png" style="width:230px;right:90px;top:110px;transform:rotate(8deg)">'+'<div class="in" style="top:80px"><div class="big">You said yes<br>when you<br><span class="b">meant no.</span></div><div class="sm">Find your <em>voice.</em></div></div>'+foot
write('sq1',1080,1080,cs,b1); job('sq1',1080,1080,'out/social/SDI_Post1_Hook_1080x1080.png')
b2=sp('lav',560,'right:-210px','top:-230px',.5)+lk()+'<div class="in" style="top:80px"><div class="big">You knew exactly<br>what you wanted<br>to say. <span class="b">Then<br>you froze.</span></div><div class="sm">Come practice using it.<br><em>Love Yourself Now.</em></div></div>'+foot
write('sq2',1080,1080,cs,b2); job('sq2',1080,1080,'out/social/SDI_Post2_Hook_1080x1080.png')
cd=cs+'''.card{background:#fff;border-radius:28px;box-shadow:0 12px 40px rgba(47,79,115,.12);padding:46px 52px;margin-top:34px}
.r{display:flex;gap:28px;padding:16px 0;border-bottom:1px solid #e3ecf3;align-items:baseline}.r:last-child{border:none}
.r .a{font-size:19px;letter-spacing:3px;font-weight:700;color:var(--green);width:130px}.r .z{font-family:Cormorant;font-weight:600;font-size:42px;color:var(--ink);line-height:1.1}.r .z small{display:block;font-family:Lato;font-weight:400;font-size:22px;color:var(--body);margin-top:4px}'''
b3=sp('lav',560,'right:-210px','top:-230px',.5)+lk()+'<div class="in" style="top:210px;justify-content:flex-start"><div class="k">LOVE YOURSELF NOW</div><div style="font-family:Cormorant;font-style:italic;font-weight:500;font-size:46px;color:var(--green)">Acknowledging Reality with Hope</div><div class="card"><div class="r"><div class="a">WHEN</div><div class="z">Thursday, November 5<small>6:30 to 8:30 PM</small></div></div><div class="r"><div class="a">WHERE</div><div class="z">Central Co-op<small>4502 N Pearl St, Tacoma, WA 98407</small></div></div><div class="r"><div class="a">COST</div><div class="z">Free to attend<small>Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span></small></div></div><div class="r"><div class="a">BRING</div><div class="z">Yourself<small>Journaling, gentle yoga, sharing circle. Refreshments provided.</small></div></div></div></div>'+foot.replace('Thu, Nov 5  ·  6:30 to 8:30 PM  ·  Central Co-op, Tacoma','Register today. Groups welcome.').replace('class="ft"','class="ft" style="bottom:110px"')+note
write('sq3',1080,1080,cd,b3); job('sq3',1080,1080,'out/social/SDI_Post3_Details_1080x1080.png')
cg=cs+'''.hs{display:flex;gap:40px;margin-top:20px}.hd{text-align:center;width:260px}.hd img{width:230px;height:230px;border-radius:50%;object-fit:cover;border:6px solid var(--lav);display:block;margin:0 auto 14px}.hd .n{font-family:Cormorant;font-style:italic;font-weight:600;font-size:40px;color:var(--ink);line-height:1.05}'''
b4=sp('lav',560,'right:-210px','top:-230px',.5)+lk()+'<div class="in" style="top:210px;justify-content:flex-start"><div class="k">YOUR GUIDES</div><div style="font-family:Cormorant;font-weight:600;font-size:64px;color:var(--ink);line-height:1.05">Credentialed Guides<br>with Lived Experience</div><div class="hs"><div class="hd"><img src="assets/vonna.png"><div class="n">Von-Na Chism</div></div><div class="hd"><img src="assets/imeko.png"><div class="n">Imeko Woods</div></div><div class="hd"><img src="assets/camella.png"><div class="n">Camella McBrayer</div></div></div><div style="font-family:Cormorant;font-style:italic;font-weight:500;font-size:40px;color:var(--plum);margin-top:34px">"Come as you are. We saved you a seat."</div></div>'+foot_hi+note
write('sq4',1080,1080,cg,b4); job('sq4',1080,1080,'out/social/SDI_Post4_Guides_1080x1080.png')

# ---------- Stories 1080x1920 (keep top 250 / bottom 340 free of key text)
cst='''.in{position:absolute;left:90px;right:90px;top:330px}
.big{font-family:Cormorant;font-style:italic;font-weight:500;font-size:104px;line-height:1.1;color:var(--ink)}.big .b{color:var(--plum)}
.t{font-family:Cormorant;font-weight:600;font-size:150px;line-height:.92;color:var(--ink);margin-top:70px;letter-spacing:-2px}.t em{font-style:italic;color:var(--plum);font-weight:500}
.ev{position:absolute;left:0;right:0;bottom:0;height:420px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;padding:60px 90px}
.ev .d{font-family:Cormorant;font-weight:600;font-size:76px;line-height:1}.ev .l{font-size:30px;line-height:1.5;margin-top:16px}'''
bs1=sp('lav',760,'right:-300px','top:-300px',.5)+sp('aqua',700,'left:-340px','top:900px',.55)+'<div style="position:absolute;left:90px;top:110px">'+lockup(88)+'</div><div class="in"><div class="big">You knew exactly what you wanted to say.<br><span class="b">Then you froze.</span></div><div class="t">Find your<br><em>voice.</em></div></div><img class="sp" src="assets/dragonfly.png" style="width:300px;right:80px;top:1010px;transform:rotate(8deg)"><div class="ev"><div class="d">Thursday, Nov 5</div><div class="l">6:30 to 8:30 PM  ·  Central Co-op, Tacoma<br>Free to attend. Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span><br>Register: soaringdragonflyinstitute.com</div></div>'
write('st1',1080,1920,cst,bs1); job('st1',1080,1920,'out/social/SDI_Story1_Hook_1080x1920.png')
bs2=sp('lav',760,'right:-300px','top:-300px',.5)+'<div style="position:absolute;left:90px;top:110px">'+lockup(88)+'</div><div class="in" style="top:420px"><div style="font-size:26px;letter-spacing:4px;font-weight:700;color:var(--green)">EARLY BIRD ENDS THURSDAY, OCT 29</div><div class="t" style="margin-top:30px;font-size:170px">Save<br>your <em>seat.</em></div><div style="font-size:34px;line-height:1.5;margin-top:50px;color:var(--ink)">A grown-up circle time for honest sharing and connection. Free to attend. Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span></div></div><img class="sp" src="assets/dragonfly.png" style="width:280px;right:90px;top:1000px;transform:rotate(8deg)"><div class="ev"><div class="d">Love Yourself Now</div><div class="l">Thursday, Nov 5  ·  6:30 to 8:30 PM  ·  Central Co-op, Tacoma<br>soaringdragonflyinstitute.com</div></div>'
write('st2',1080,1920,cst,bs2); job('st2',1080,1920,'out/social/SDI_Story2_EarlyBird_1080x1920.png')

# ---------- Link share / LinkedIn 1200x630
cl='''.in{position:absolute;left:80px;top:0;bottom:0;display:flex;flex-direction:column;justify-content:center}
.h{font-family:Cormorant;font-weight:600;font-size:120px;line-height:.92;color:var(--ink);letter-spacing:-1px}.h em{font-style:italic;color:var(--plum);font-weight:500}
.p{font-family:Cormorant;font-style:italic;font-weight:500;font-size:34px;color:var(--blue);margin-top:16px}.d{font-size:21px;margin-top:20px;color:var(--ink);line-height:1.5}'''
bl=sp('aqua',420,'right:-150px','bottom:-210px',.7)+'<div style="position:absolute;right:70px;top:50px">'+lockup(60)+'</div><div class="in"><div style="font-size:15px;letter-spacing:3px;font-weight:700;color:var(--blue);margin-bottom:12px">LOVE YOURSELF NOW</div><div class="h">Find your<br><em>voice.</em></div><div class="p">It never left. Come practice using it.</div><div class="d"><b>Thu, Nov 5, 6:30 to 8:30 PM</b> · Central Co-op, Tacoma<br>Free to attend. Donations gratefully accepted.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span><br>soaringdragonflyinstitute.com</div></div><img class="sp" src="assets/dragonfly.png" style="width:260px;right:120px;top:230px;transform:rotate(8deg)">'
write('li',1200,630,cl,bl); job('li',1200,630,'out/social/SDI_LinkedIn_LinkShare_1200x630.png')
render.run(jobs)
