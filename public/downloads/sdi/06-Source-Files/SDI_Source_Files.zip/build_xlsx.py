import csv, datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
S='/tmp/claude-0/-home-claude/f6f36626-01ab-5357-9730-d6f627b6a8c2/scratchpad/'
INK='2F4F73'; AQ='DCF4F8'
hf=Font(name='Calibri',bold=True,color='FFFFFF',size=11); hfill=PatternFill('solid',fgColor=INK)
thin=Side(style='thin',color='C9D6E2'); bd=Border(left=thin,right=thin,top=thin,bottom=thin)
wb=Workbook()
def sheet(title,headers,rows,widths,track=None,statuses=None,pri_col=None):
    ws=wb.create_sheet(title); ws.append(headers)
    for r in rows: ws.append(r)
    for c in range(1,len(headers)+1):
        cell=ws.cell(1,c); cell.font=hf; cell.fill=hfill; cell.alignment=Alignment(wrap_text=True,vertical='center')
        ws.column_dimensions[get_column_letter(c)].width=widths[c-1]
    ws.row_dimensions[1].height=32
    for row in ws.iter_rows(min_row=2,max_row=ws.max_row):
        for cell in row: cell.alignment=Alignment(wrap_text=True,vertical='top'); cell.border=bd; cell.font=Font(name='Calibri',size=10)
    ws.freeze_panes='C2'; ws.auto_filter.ref=ws.dimensions
    if track:
        for c in track:
            for r in range(2,ws.max_row+1): ws.cell(r,c).fill=PatternFill('solid',fgColor='F4FAFC')
            ws.cell(1,c).fill=PatternFill('solid',fgColor='4F80B2')
    if statuses:
        dv=DataValidation(type='list',formula1='"'+','.join(statuses[1])+'"',allow_blank=True); ws.add_data_validation(dv)
        dv.add(f'{get_column_letter(statuses[0])}2:{get_column_letter(statuses[0])}{ws.max_row}')
    if pri_col:
        for r in range(2,ws.max_row+1):
            v=ws.cell(r,pri_col).value
            col={'A':'C8E6C9','B':'FFF3C4','C':'E8E8E8'}.get(v)
            if col: ws.cell(r,pri_col).fill=PatternFill('solid',fgColor=col)
    return ws
# ---- Read Me
ws=wb.active; ws.title='Read Me'
lines=[('SOARING DRAGONFLY INSTITUTE: LOVE YOURSELF NOW, OUTREACH WORKBOOK',True),
('Prepared by Ascend Consulting LLC for Camella McBrayer, Imeko Woods and Von-Na Chism. Built October 4, 2026.',False),('',False),
('EVENT FACTS USED EVERYWHERE',True),
('Two Thursdays to choose from: Nov 5 or Nov 12, 2026, 6:30 to 8:30 PM on both. The Mountaineers (Boardroom), 2302 N 30th St, Tacoma, WA 98403.',False),
('Cost: $35 early bird through Oct 29, $50 advance, $60 at the door.',False),
('A $497 value. Includes: two hours led by a credentialed guide who walks this road alongside you; a daily writing practice adapted from The Artist\'s Way by Julia Cameron; growing awareness of the experience of heart, mind, and body alignment; ways to name what you feel, even when words won\'t come; gentle movement; a clear structure for practice.',False),
('Register: soaringdragonflyinstitute.com. Guides: Credentialed Guides that Share the Journey. One of the three named guides leads each evening; when naming all three, add: One of these credentialed guides will lead your evening. Use the exact Notice and Disclaimer on anything that describes the session. Avoid: therapy, therapeutic, treatment, clinical, healing, heal, client. Say participant and closing practice. Never mention Medicaid or insurance.',False),('',False),
('TABS',True),
('Visit Plan: 52 places to walk into, grouped by walking cluster and priority. Start with Priority A. Tracking columns are shaded light blue.',False),
('Social Groups: online groups, pages and newsletters. 17 Facebook groups were seen directly in a logged-in Facebook search on Oct 4; their member counts are as displayed that day.',False),
('Event Listings: calendars and submission pages, with a suggested submit-by date.',False),
('Posting Etiquette: rules of thumb to avoid getting removed or banned.',False),
('Launch Calendar: week-by-week checklist from Oct 5 to Nov 13 with an owner for each task.',False),('',False),
('HONEST CAVEATS',True),
('1. Nothing here was verified by phone. Addresses, phones and websites come from business sites or directories fetched Oct 4. Call or check hours before a long walk.',False),
('2. No business had a posted flyer policy we could find. Ask in person. A polite no is normal.',False),
('3. Facebook group rules could not be read from outside the groups. Read each group\'s rules tab before posting, and message admins first where marked.',False),
('4. Gatekeeper titles are generic suggestions, not named staff. Write the real names in the tracking columns as you learn them.',False),
('5. Coworking spaces and community centers are thin in this list. Add them as you find them on your own route.',False),
('6. Center for Spiritual Living holds a Thursday 7 PM meditation that overlaps both Thursdays (Nov 5 and Nov 12). Ask before assuming they will help.',False),
('7. Several listing sites had no fee or deadline information available. Treat "not found" as "ask or check the form".',False),
('8. Walking clusters and priorities were set around the earlier venue address. The new venue is 2302 N 30th St, so review the Priority A choices against distance before you walk.',False)]
for i,(t,b) in enumerate(lines,1):
    c=ws.cell(i,1,t); c.font=Font(name='Calibri',bold=b,size=13 if i==1 else 11,color=INK if b else '333333'); c.alignment=Alignment(wrap_text=True,vertical='top')
ws.column_dimensions['A'].width=130
# ---- Visit Plan
rows=list(csv.DictReader(open(S+'outreach_businesses.csv')))
order={'A':0,'B':1,'C':2}
rows.sort(key=lambda r:(order.get(r['Priority'],3),r['Walking cluster'],r['Name']))
h=['Priority','Walking cluster','Name','Category','Street address','Phone','Website','Best person to ask for','What to leave','How to approach','Why it fits','Hours seen','Posted flyer policy','Verification','Status','Date visited','Contact name','Notes / follow-up']
data=[[r['Priority'],r['Walking cluster'],r['Name'],r['Category'],r['Street address'],r['Phone'],r['Website'],r['Best gatekeeper'],r['What to leave'],r['Approach note'],r['Why it fits'],r['Hours seen'],r['Posted flyer policy'],r['Verification status'],'To visit','','',''] for r in rows]
sheet('Visit Plan',h,data,[8,18,30,18,34,15,32,24,14,50,40,24,16,20,14,12,18,40],track=[15,16,17,18],statuses=(15,['To visit','Visited, left materials','Visited, asked to return','Declined','Agreed to display','Agreed to resource table','Skip']),pri_col=1)
# ---- Social Groups
fb=[('Facebook group (seen in FB search 10/4/26)',"Tacoma Community Happenings Page",'https://www.facebook.com/groups/299814863856885/','Local happenings, Tacoma','6.7K members, ~2 posts/day','Public','Rules unverified, check inside group','Read rules, then post once. Strong fit.','A'),
('Facebook group (seen in FB search 10/4/26)','Tacoma Town Talk - Tacoma, WA.','Search exact name on Facebook','General Tacoma community','8.6K members','Public','Rules unverified, check inside group','Read rules, then post once','A'),
('Facebook group (seen in FB search 10/4/26)','Tacoma Events','Search exact name on Facebook','Tacoma events','12K members, ~9 posts/day','Private','Rules unverified, check inside group','Request to join, read rules, post once','A'),
('Facebook group (seen in FB search 10/4/26)','Tacoma/Pierce County Community & Family Resources','Search exact name on Facebook','Community resources','10K members, ~6 posts/day','Public','Rules unverified, check inside group','Message admin first; frame as free community resource','B'),
('Facebook group (seen in FB search 10/4/26)',"WHAT'S HAPPENING IN SEATTLE / TACOMA!",'https://www.facebook.com/groups/363726013705054/','Regional events','45K members, 60+ posts/day','Public','Rules unverified, check inside group','Post once; expect it to scroll away fast. Repost a reminder only if allowed.','B'),
('Facebook group (seen in FB search 10/4/26)','PNW Events','https://www.facebook.com/groups/353447602270217/','Pacific Northwest events','7.2K members, 10+ posts/day','Public','Rules unverified, check inside group','Read rules, post once','B'),
('Facebook group (seen in FB search 10/4/26)','New to Tacoma, Washington','Search exact name on Facebook','Newcomers looking for community','11K members','Public','Rules unverified, check inside group','Message admin first','B'),
('Facebook group (seen in FB search 10/4/26)','Yoga Community NW','Search exact name on Facebook','Movement practitioners, Pacific Northwest','5.8K members, ~5 posts/day','Public','Rules unverified, check inside group','Message admin first. Best audience match among large groups.','A'),
('Facebook group (seen in FB search 10/4/26)','Puget Sound Yoga and Meditation Community','Search exact name on Facebook','Movement and meditation, Puget Sound','1.5K members, ~2 posts/day','Public','Rules unverified, check inside group','Message admin first. Strong match.','A'),
('Facebook group (seen in FB search 10/4/26)','Breathe Tacoma Conscious Community','Search exact name on Facebook','Conscious community, Tacoma','225 members','Public','Rules unverified, check inside group','Message admin first. Small but exactly the audience.','A'),
('Facebook group (seen in FB search 10/4/26)','Tacoma Girls Book Club','Search exact name on Facebook','Book club, Tacoma','759 members','Private','Rules unverified, check inside group','Message admin first. Book-club angle (The Artist\'s Way) fits.','A'),
('Facebook group (seen in FB search 10/4/26)','Helping Small businesses of Tacoma','Search exact name on Facebook','Local small business owners','26K members, ~7 posts/day','Public','Rules unverified, check inside group','Angle for founders and high performers. Many business groups limit promotion, check rules.','B'),
('Facebook group (seen in FB search 10/4/26)','Tacoma, Washington Small Business','https://www.facebook.com/groups/844059937321018/','Local small business owners','13K members, ~90 posts/day','Public','Rules unverified, check inside group','Busy feed, low odds; use only if rules allow events','C'),
('Facebook group (seen in FB search 10/4/26)','Gig Harbor & Tacoma Business Owners Working Together','Search exact name on Facebook','Business owners, Gig Harbor and Tacoma','3.1K members, 10+ posts/day','Public','Rules unverified, check inside group','Message admin first','B'),
('Facebook group (seen in FB search 10/4/26)','Seattle / Tacoma Businesses','Search exact name on Facebook','Business owners','11K members, 20+ posts/day','Public','Rules unverified, check inside group','Read rules; low priority','C'),
('Facebook group (seen in FB search 10/4/26)','Small business support group: Tacoma-Seattle','Search exact name on Facebook','Business owners','9.8K members, 40+ posts/day','Public','Rules unverified, check inside group','Read rules; low priority','C'),
('Facebook group (seen in FB search 10/4/26)','TacroYoga (Tacoma+Acrobatic+Yoga)','Search exact name on Facebook','Acrobatic movement community','584 members','Public','Rules unverified, check inside group','Different crowd; low priority','C')]
g=[[a,b,c,d,e,f,g_,hh,fit,'Seen directly in a logged-in Facebook search, Oct 4, 2026','Not started','','' ] for (a,b,c,d,e,f,g_,hh,fit) in fb]
for r in csv.DictReader(open(S+'social_groups.csv')):
    if r['Platform'].startswith('Facebook') and r['Name'] in ('Tacoma Dad\'s Group','Pierce Community Network','New Tacoma Neighborhood Council','Tacoma Venues & Events','Tacoma Photography Group'): continue
    g.append([r['Platform'],r['Name'],r['URL'],r['Audience/Topic'],r['Public size (members/followers if visible)'],r['Public/Private'],r['Promotion policy or rules (if visible)'],r['Recommended approach'],r['Fit (A/B/C)'],r['Verification status and source URL'],'Not started','',''])
g.sort(key=lambda r:(order.get(r[8],3)))
sheet('Social Groups',['Platform','Name','URL or how to find','Audience / topic','Size','Public / private','Rules or promotion policy','Recommended approach','Fit','Verification and source','Status','Date posted / contacted','Notes'],g,[24,36,38,32,24,12,34,44,6,40,14,14,34],track=[11,12,13],statuses=(11,['Not started','Admin messaged','Approved','Posted','Declined','Skip']),pri_col=9)
# ---- Event listings
sub={'Visit Tacoma-Pierce County':'Oct 6','KNKX Community Calendar':'Oct 12','Daily Tacoma Events':'Oct 8','Patch Tacoma Calendar':'Oct 12','Eventbrite':'Oct 6','SouthSoundTalk Pierce County Events Calendar':'Oct 8','Gig Harbor Now Events Calendar':'Oct 12','Tacoma Weekly Submit Events':'Oct 6','The News Tribune Event Submission':'Oct 6','Facebook Events (organization page)':'Oct 5','BaseLocal Tacoma':'Oct 12'}
e=[]
for r in csv.DictReader(open(S+'event_listings.csv')):
    if r['Name'] in ('Exit133','Do253'): continue
    e.append([sub.get(r['Name'],'Oct 12 (or when verified)'),r['Name'],r['URL'],r['Submission link or method'],r['Cost'],r['Submission deadline or lead time'],r['Typical audience'],r['Requirements'],r['Notes'],r['Verification status and source URL'],'Not submitted','',''])
e.sort(key=lambda r:(r[0]=='Oct 12 (or when verified)',r[0]))
sheet('Event Listings',['Suggested submit by','Name','URL','How to submit','Cost','Lead time / deadline','Audience','Requirements','Notes','Verification and source','Status','Date submitted','Link to live listing / notes'],e,[16,34,36,40,22,26,26,34,40,40,14,14,34],track=[11,12,13],statuses=(11,['Not submitted','Submitted','Live','Rejected','Skip']))
# ---- Etiquette
ws2=wb.create_sheet('Posting Etiquette'); ws2.column_dimensions['A'].width=140
ws2.cell(1,1,'Posting etiquette and group-rule risks').font=Font(bold=True,size=13,color=INK)
for i,l in enumerate([x.strip('- ').strip() for x in open(S+'etiquette.txt').read().split('\n') if x.startswith('- ')],2):
    c=ws2.cell(i,1,f'{i-1}. {l}'); c.alignment=Alignment(wrap_text=True,vertical='top')
# ---- Calendar
cal=[('Mon Oct 5','Camella','Return from Sacramento. Confirm the registration page works end to end (test sign-up, confirmation email).'),
('Mon Oct 5','Camella','Upload website hero graphic from the Web folder above the registration form, and swap in new flyer.'),
('Mon Oct 5','Camella','Create two Facebook Events (Nov 5 and Nov 12) using the event cover and the description in the playbook. Invite page followers.'),
('Mon Oct 5','Camella','Post Social Post 1 on the Facebook page. Share the event to your personal profile.'),
('Tue Oct 6','Camella','Submit listings marked Oct 5 or Oct 6 on the Event Listings tab (Eventbrite, Visit Tacoma-Pierce County, Tacoma Weekly, News Tribune).'),
('Tue Oct 6 to Fri Oct 9','Camella','Walk Cluster 1, Priority A places on the Visit Plan with rack cards and poster. Aim for 6 to 8 visits.'),
('Wed Oct 7','Camella','Send admin messages to Priority A Facebook groups (message first, post after approval).'),
('Thu Oct 8','Camella','Submit Daily Tacoma and SouthSoundTalk listings.'),
('Fri Oct 9','Camella','Check-in: review registrations and which channels sent traffic (QR codes carry utm tags: flyer, rack, poster, web).'),
('Mon Oct 12','Camella','Post Social Post 2. Submit remaining listings (KNKX, Patch, Gig Harbor Now, others).'),
('Oct 12 to 16','Camella','Walk Cluster 2 and remaining Priority A places. Leave brochure-swap letters for the resource table.'),
('Oct 12 to 16','Camella','Post in approved Facebook groups, at most two groups per day, staggered.'),
('Wed Oct 14','Camella','Post Social Post 4 (guide).'),
 ('Mon Oct 19','Camella','Post Social Post 3 (details) and a Story. Email or text your personal list with a personal invite.'),
('Oct 19 to 23','Camella','Second pass: Priority B places near Proctor and 6th Ave. Return to anyone who asked you to come back.'),
('Thu Oct 22','Camella and team','DECISION POINT: compare registrations to the goal. If well behind, widen outreach (Priority B/C, personal invites) and ask partners for a newsletter mention.'),
('Mon Oct 26','Camella','Early bird countdown: Story 2 and a Facebook page post ("Early bird ends Thursday").'),
('Thu Oct 29','Camella','Last day of $35 early bird for both Thursdays. Reminder post in the morning.'),
('Mon Nov 2','Camella','Text post that Nov 5 is this week and Nov 12 is next (no graphic). Send reminder to everyone registered for Nov 5 (time, address, parking, what to bring).'),
('Wed Nov 4','Camella','Day-before reminder on the page and the Nov 5 Facebook Event. Confirm Boardroom access, refreshments and printed survey.'),
('Thu Nov 5','One of the three guides','FIRST SESSION. Resource table with partner brochures. Hand out the short feedback survey at the end.'),
('Fri Nov 6','Camella','Thank-you message to the Nov 5 group and survey summary. Offer Nov 12 to anyone who still wants to join.'),
 ('Mon Nov 9','Camella','Text post that Nov 12 is this week (no graphic). Send reminder to everyone registered for Nov 12 (time, address, parking, what to bring).'),
 ('Wed Nov 11','Camella','Day-before reminder on the page and the Nov 12 Facebook Event. Confirm Boardroom access, refreshments and printed survey.'),
 ('Thu Nov 12','One of the three guides','SECOND SESSION. Resource table with partner brochures. Hand out the short feedback survey at the end.'),
 ('Fri Nov 13','Camella','Thank-you message, survey summary of both sessions, announce the next session to everyone who attended.')]
sheet('Launch Calendar',['When','Owner','Task','Done?'],[[a,b,c,''] for a,b,c in cal],[22,18,110,10],track=[4],statuses=(4,['','Yes','No']))

# ---- wording sweep (Camella feedback): keep real business/group names and URLs, rewrite descriptive text
import re as _re
KEEP=["Expand Yoga Tacoma","Source Yoga North Tacoma","Source Yoga (North Tacoma)","Source Yoga","Tuladhara Yoga Tacoma","Tuladhara Yoga Gig Harbor","Tacoma Yoga by Tuladhara","Yoga Wild","Asha Yoga and Wellness (Gig Harbor)","Yoga Community NW","Puget Sound Yoga and Meditation Community","TacroYoga (Tacoma+Acrobatic+Yoga)"]
def _fix(v):
    if not isinstance(v,str) or v.startswith('http'): return v
    keep={}
    for i,k in enumerate(sorted(KEEP,key=len,reverse=True)):
        if k in v: v=v.replace(k,f'@@{i}@@'); keep[f'@@{i}@@']=k
    v=v.replace('Yoga/Pilates/Barre','Movement/Pilates/Barre')
    v=v.replace('inner child and journaling themes','journaling themes').replace('inner child reflection theme','reflection theme')
    v=v.replace('non-clinical peer circle','non-clinical circle')
    v=v.replace('"free, donations welcome, non-clinical, peer-led."','"free launch, suggested donation, non-clinical."')
    v=_re.sub(r'yoga','movement',v); v=_re.sub(r'Yoga','Movement',v)
    for k,o in keep.items(): v=v.replace(k,o)
    return v
for _ws in wb:
    for _row in _ws.iter_rows():
        for _c in _row:
            if isinstance(_c.value,str): _c.value=_fix(_c.value)

_OV={
"Ask before class rush; pitch as free community event, offer a rack card for the front desk.":"Ask before class rush; pitch as a community evening, offer a rack card for the front desk.",
"Highest proximity; tell them the event is on their block.":"Neighborhood business; ask if they will display a poster.",
"Next door to the venue address (4502 N Pearl); neighbors may attend and can walk over.":"Neighborhood audience; owner may be glad to display a poster.",
"Ask owner about cross-promotion; very close to venue.":"Ask owner about cross-promotion.",
"Closest cluster to venue; walk in between class blocks.":"Walk in between class blocks.",
"Walkable from the event venue; joint-friendly small-group clients.":"Joint-friendly small-group clients.",
"Closest library to venue; community board commonly used.":"Community board commonly used.",
"Group practice a block from the venue area; therapists can refer clients to a non-clinical circle.":"Group practice; therapists can refer clients to a non-clinical circle.",
"Outside walkable range, include only for a drive loop.":"Outside walkable range, include only for a drive loop.",
"Natural foods shopper audience; farther from venue.":"Natural foods shopper audience; outlying location.",
"Message admin first; frame as free community resource":"Message admin first; frame as a community resource",
"use Custom pricing for free/donation":"use ticket price tiers for the early bird, advance and door prices",
}
for _ws in wb:
    for _row in _ws.iter_rows():
        for _c in _row:
            if isinstance(_c.value,str):
                v=_c.value
                for k,n in _OV.items(): v=v.replace(k,n)
                v=v.replace("(what, when, where, free, non-clinical)","(what, when, where, cost, non-clinical)").replace('say plainly "free launch, suggested donation, non-clinical."','say plainly the dates, the cost and "non-clinical."')
                v=v.replace("Note the Nov 5 event is also a Thursday evening","Note the events are on Thursday evenings (Nov 5 and Nov 12)")
                v=v.replace("donations would need ticketing setup (not verified)","ticketing setup needed for paid tickets (not verified)").replace("free event fees nil","fees for paid tickets not verified")
                _c.value=v

_OV2=[("No fee; donation encouraged","No fee"),("weekly Wednesday sessions, donation based","weekly Wednesday sessions"),("Free; donation encouraged","No fee"),("Posting free; promotion paid","No fee to post; promotion paid"),("Appears free (not stated)","Appears no fee (not stated)"),("not stated (appears free)","not stated (appears no fee)"),("Free for Business Page posts","No fee for Business Page posts"),("Free events: unlimited at no cost","Events without ticket fees: unlimited at no cost"),("title, free/paid, location","title, price, location"),("Free weekly email","Weekly email"),("Free online meditation and mindfulness","Online meditation and mindfulness"),("spirituality conversations, free","spirituality conversations"),("businesses must use free Business Pages","businesses must use Business Pages (no fee)"),("businesses should use free Business Pages","businesses should use Business Pages (no fee)"),("no free submission method found","only a paid advertising option found")]
for _ws in wb:
    for _row in _ws.iter_rows():
        for _c in _row:
            if isinstance(_c.value,str):
                v=_c.value
                for a,b in _OV2: v=v.replace(a,b)
                if _ws.title=='Event Listings' and v.strip()=='Free': v='No fee'
                _c.value=v
wb.save('out/SDI_Outreach_Workbook.xlsx'); print(len(data),len(g),len(e))
