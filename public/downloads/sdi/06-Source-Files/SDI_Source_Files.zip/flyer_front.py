from lockup import lockup
html=f'''<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="brand.css"><style>
body{{width:816px;height:1056px}}
.page{{width:816px;height:1056px}}
.lock{{position:absolute;left:56px;top:48px}}
.hook{{position:absolute;left:56px;top:124px;width:700px;font-family:Cormorant;font-style:italic;font-weight:500;font-size:33px;line-height:1.34;color:var(--ink)}}
.hook span{{display:block}} .hook .b{{color:var(--plum);padding-left:56px}}
.title{{position:absolute;left:52px;top:322px;font-family:Cormorant;font-weight:600;font-size:134px;line-height:.9;color:var(--ink);letter-spacing:-2px}}
.title em{{font-style:italic;color:var(--plum);font-weight:500}}
.df{{position:absolute;left:588px;top:344px;width:196px;transform:rotate(8deg)}}
.never{{position:absolute;left:58px;top:560px;font-family:Cormorant;font-style:italic;font-weight:500;font-size:34px;color:var(--blue)}}
.event{{position:absolute;left:56px;top:622px;width:704px;display:flex;gap:22px;align-items:center}}
.event img.cv{{width:78px;border:1px solid #c5d3df;border-radius:2px}}
.event .t1{{font-family:Cormorant;font-weight:600;font-size:40px;color:var(--plum);letter-spacing:1px;line-height:1}}
.event .t2{{font-family:Cormorant;font-style:italic;font-weight:500;font-size:24px;color:var(--green);margin:2px 0 6px}}
.event .t3{{font-size:13.5px;line-height:1.45;color:var(--body);max-width:520px}}
.band{{position:absolute;left:0;right:0;bottom:0;height:300px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;padding:28px 56px 0}}
.band .d{{font-family:Cormorant;font-weight:600;font-size:44px;line-height:1}}
.band .l{{font-size:15px;margin-top:6px;letter-spacing:.3px;line-height:1.5}}
.band .f{{margin-top:14px}} .band .f .p{{font-family:Cormorant;font-weight:700;font-size:36px;line-height:1.1;color:#fff;letter-spacing:.2px}} .band .f .vv{{font-size:14px;margin-top:6px;color:#dcecf7;letter-spacing:.4px}}
.qr{{position:absolute;right:56px;top:30px;width:136px;background:#fff;border-radius:12px;padding:10px;text-align:center}}
.qr img{{width:116px;display:block}} .qr div{{font-size:10px;color:var(--ink);font-weight:700;letter-spacing:1.2px;margin-top:2px}}
.url{{position:absolute;right:56px;bottom:26px;font-size:17px;letter-spacing:.8px;font-weight:700}}
.ns{{position:absolute;left:56px;bottom:16px;font-size:10.5px;color:#cfe3f3}}
</style></head><body><div class="page">
<img class="sp" src="assets/spiral_lav.svg" style="width:430px;right:-190px;top:-170px;opacity:.5">
<img class="sp" src="assets/spiral_aqua.svg" style="width:460px;left:-300px;top:520px;opacity:.55">
<div class="lock">{lockup(52)}</div>
<div class="hook"><span>You hear everyone else.</span><span>You know what they need.</span><span class="b">Somewhere along the way,</span><span class="b">you stopped hearing yourself.</span></div>
<div class="title">Find your<br><em>voice.</em></div>
<img class="df" src="assets/dragonfly.png">
<div class="never">It never left. Come practice hearing it.</div>
<div class="event"><img class="cv" src="assets/artists_way_cover.png"><div><div class="t1">LOVE YOURSELF NOW</div><div class="t2">Acknowledging Reality with Hope</div><div class="t3">A grown-up circle time for honest sharing and connection: journaling, gentle movement, and an exercise from <i>The Artist's Way</i> by Julia Cameron.</div></div></div>
<div class="band"><div class="d">Thursday, Nov 5 or Nov 12</div>
<div class="l">6:30 to 8:30 PM &nbsp;·&nbsp; Pick the Thursday that suits your schedule.<br>The Mountaineers, Boardroom &nbsp;·&nbsp; 2302 N 30th St, Tacoma, WA 98403</div>
<div class="f"><div class="p">$35 early bird through Oct 29,<br>$50 advance, $60 at the door.</div><div class="vv">A $497 value* &nbsp;<span style="opacity:.8">See the back for what's included.</span></div></div>
<div class="qr"><img src="assets/qr_flyer.png"><div>SCAN TO REGISTER</div></div>
<div class="url">soaringdragonflyinstitute.com</div></div>
</div></body></html>'''
open('flyer_front.html','w').write(html)
