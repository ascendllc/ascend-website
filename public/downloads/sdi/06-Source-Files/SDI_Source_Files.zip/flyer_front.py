from lockup import lockup
html=f'''<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="brand.css"><style>
body{{width:816px;height:1056px}}
.page{{width:816px;height:1056px}}
.lock{{position:absolute;left:56px;top:48px}}
.hook{{position:absolute;left:56px;top:138px;width:700px;font-family:Cormorant;font-style:italic;font-weight:500;font-size:33px;line-height:1.34;color:var(--ink)}}
.hook span{{display:block}} .hook .b{{color:var(--plum);padding-left:56px}}
.title{{position:absolute;left:52px;top:350px;font-family:Cormorant;font-weight:600;font-size:134px;line-height:.9;color:var(--ink);letter-spacing:-2px}}
.title em{{font-style:italic;color:var(--plum);font-weight:500}}
.df{{position:absolute;left:588px;top:372px;width:196px;transform:rotate(8deg)}}
.never{{position:absolute;left:58px;top:600px;font-family:Cormorant;font-style:italic;font-weight:500;font-size:34px;color:var(--blue)}}
.event{{position:absolute;left:56px;top:664px;width:704px;display:flex;gap:22px;align-items:center}}
.event img.cv{{width:78px;border:1px solid #c5d3df;border-radius:2px}}
.event .t1{{font-family:Cormorant;font-weight:600;font-size:40px;color:var(--plum);letter-spacing:1px;line-height:1}}
.event .t2{{font-family:Cormorant;font-style:italic;font-weight:500;font-size:24px;color:var(--green);margin:2px 0 6px}}
.event .t3{{font-size:13.5px;line-height:1.45;color:var(--body);max-width:520px}}
.band{{position:absolute;left:0;right:0;bottom:0;height:238px;background:linear-gradient(135deg,var(--card),var(--deep));color:#fff;padding:34px 56px 0}}
.band .d{{font-family:Cormorant;font-weight:600;font-size:46px;line-height:1}}
.band .l{{font-size:16px;margin-top:8px;letter-spacing:.3px;line-height:1.5}}
.band .f{{font-size:13.5px;margin-top:8px;color:#dcecf7}}
.qr{{position:absolute;right:56px;top:30px;width:136px;background:#fff;border-radius:12px;padding:10px;text-align:center}}
.qr img{{width:116px;display:block}} .qr div{{font-size:10px;color:var(--ink);font-weight:700;letter-spacing:1.2px;margin-top:2px}}
.url{{position:absolute;left:56px;bottom:46px;font-size:17px;letter-spacing:.8px;font-weight:700}}
.ns{{position:absolute;left:56px;bottom:16px;font-size:10.5px;color:#cfe3f3}}
</style></head><body><div class="page">
<img class="sp" src="assets/spiral_lav.svg" style="width:430px;right:-190px;top:-170px;opacity:.5">
<img class="sp" src="assets/spiral_aqua.svg" style="width:460px;left:-300px;top:520px;opacity:.55">
<div class="lock">{lockup(52)}</div>
<div class="hook"><span>You knew exactly what you wanted to say.</span><span class="b">Then you froze.</span><span>Your mind went blank.</span><span class="b">You said yes when you meant no.</span></div>
<div class="title">Find your<br><em>voice.</em></div>
<img class="df" src="assets/dragonfly.png">
<div class="never">It never left. Come practice using it.</div>
<div class="event"><img class="cv" src="assets/artists_way_cover.png"><div><div class="t1">LOVE YOURSELF NOW</div><div class="t2">Acknowledging Reality with Hope</div><div class="t3">A grown-up circle time for honest sharing and connection: journaling, gentle yoga, inner child reflection, and an exercise from <i>The Artist's Way</i> by Julia Cameron.</div></div></div>
<div class="band"><div class="d">Thursday, November 5</div>
<div class="l">6:30 to 8:30 PM &nbsp;·&nbsp; Central Co-op &nbsp;·&nbsp; 4502 N Pearl St, Tacoma, WA 98407</div>
<div class="f">Free to attend. Donations gratefully accepted, never required.<br><span class="sg">Suggested: $35 early bird through Oct 29, $50 advance, $60 at the door.</span></div>
<div class="qr"><img src="assets/qr_flyer.png"><div>SCAN TO REGISTER</div></div>
<div class="url">soaringdragonflyinstitute.com</div><div class="ns">This event is not sponsored by Central Co-op.</div></div>
</div></body></html>'''
open('flyer_front.html','w').write(html)
