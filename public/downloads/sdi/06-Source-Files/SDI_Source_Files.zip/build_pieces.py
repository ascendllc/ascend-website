import render, pypdf, shutil
# run after: python3 flyer_front.py; python3 flyer_back.py; python3 graphics.py; python3 printpieces.py
render.run([dict(html='flyer_front.html',w=816,h=1056,png='out/SDI_Flyer_Front.png',pdf='out/_ff.pdf',scale=3.125),
            dict(html='flyer_back.html',w=816,h=1056,png='out/SDI_Flyer_Back.png',pdf='out/_fb.pdf',scale=3.125)])
def merge(a,b,o):
    w=pypdf.PdfWriter()
    for f in (a,b): w.add_page(pypdf.PdfReader(f).pages[0])
    w.write(o)
merge('out/_ff.pdf','out/_fb.pdf','out/SDI_Flyer_2-Page_Print.pdf')
merge('out/print/_rf.pdf','out/print/_rb.pdf','out/print/SDI_Rack_Card_4x9_Front-Back.pdf')
shutil.copy('out/print/_rf.png','out/print/SDI_Rack_Card_Front.png'); shutil.copy('out/print/_rb.png','out/print/SDI_Rack_Card_Back.png')
